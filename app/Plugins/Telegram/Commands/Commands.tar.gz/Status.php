<?php

namespace App\Plugins\Telegram\Commands;

use App\Services\TelegramService;
use App\Models\User;
use Carbon\Carbon;

class Status
{
    public $command = '/status';
    
    public function handle($msg)
    {
        $telegramService = new TelegramService();
        
        $user = User::where('telegram_id', $msg->chat_id)->first();
        if (!$user) {
            $telegramService->sendMessage($msg->chat_id, '❌ 未找到绑定的用户信息');
            return;
        }
        
        $statusText = "👤 *账户状态*\n\n";
        $statusText .= "📧 邮箱: " . $this->escapeMarkdown($user->email) . "\n";
        $statusText .= "📅 到期时间: " . Carbon::parse($user->expired_at)->format('Y-m-d H:i') . "\n";
        $statusText .= "🚫 封禁状态: " . ($user->banned ? '❌ 已封禁' : '✅ 正常') . "\n\n";
        
        $statusText .= "🔔 *通知设置*\n";
        $statusText .= "状态: " . ($user->telegram_daily_traffic_notify ? '🟢 已开启' : '🔴 已关闭') . "\n";
        $statusText .= "时间: " . ($user->telegram_notify_time ?? '23:50') . "\n\n";
        
        // 计算剩余天数
        $remainingDays = Carbon::now()->diffInDays(Carbon::parse($user->expired_at), false);
        if ($remainingDays > 0) {
            $statusText .= "⏰ 服务剩余: {$remainingDays} 天";
        } else {
            $statusText .= "⚠️ 服务已过期";
        }
        
        $telegramService->sendMessage($msg->chat_id, $statusText, 'markdown');
    }
    
    private function escapeMarkdown($text)
    {
        $escapeChars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'];
        foreach ($escapeChars as $char) {
            $text = str_replace($char, '\\' . $char, $text);
        }
        return $text;
    }
}