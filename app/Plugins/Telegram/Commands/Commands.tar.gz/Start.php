<?php

namespace App\Plugins\Telegram\Commands;

use App\Models\User;
use App\Plugins\Telegram\Telegram;

class Start extends Telegram
{
    public $command = '/start';
    public $description = '开始使用机器人';
    
    public function handle($message, $match = [])
    {
        if (!$message->is_private) return;
        
        $user = User::where('telegram_id', $message->chat_id)->first();
        
        if (!$user) {
            $welcomeText = "🤖 欢迎使用机器人！\n———————————————\n";
            $welcomeText .= "❌ 检测到您尚未绑定账户\n\n";
            $welcomeText .= "请先访问用户中心，在个人设置中绑定您的 Telegram 账户，";
            $welcomeText .= "绑定成功后即可使用以下功能：\n\n";
            $welcomeText .= "📊 流量查询\n";
            $welcomeText .= "🚪 内部群组邀请\n";
            $welcomeText .= "🔔 每日流量通知\n";
            $welcomeText .= "⏰ 自定义通知时间\n\n";
            $welcomeText .= "输入 /help 查看详细命令说明";
        } else {
            $welcomeText = "🤖 欢迎回来！\n———————————————\n";
            $welcomeText .= "✅ 账户已绑定：" . $user->email . "\n\n";
            $welcomeText .= "可用功能：\n";
            $welcomeText .= "📊 /traffic - 查看流量使用情况\n";
            $welcomeText .= "🚪 /join - 获取内部群组邀请链接\n";
            $welcomeText .= "🔔 /notify_on - 开启每日流量通知\n";
            $welcomeText .= "🔕 /notify_off - 关闭每日流量通知\n";
            $welcomeText .= "⏰ /notify_time - 设置通知时间\n";
			$welcomeText .= "🔄 /subscribe_notify_on - 开启订阅拉取通知\n";
			$welcomeText .= "🔕 /subscribe_notify_off - 关闭订阅拉取通知\n";
            $welcomeText .= "❓ /help - 查看帮助信息\n\n";
            // 在当前设置部分添加
			$subscribeNotifyStatus = $user->telegram_subscribe_notify ? '🟢 已开启' : '🔴 已关闭';
			$welcomeText .= "订阅通知：{$subscribeNotifyStatus}\n";
            $notifyStatus = $user->telegram_daily_traffic_notify ? '🟢 已开启' : '🔴 已关闭';
            $welcomeText .= "当前通知状态：{$notifyStatus}";
        }
        
        $this->telegramService->sendMessage($message->chat_id, $welcomeText);
    }
}