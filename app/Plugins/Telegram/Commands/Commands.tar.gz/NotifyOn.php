<?php

namespace App\Plugins\Telegram\Commands;

use App\Services\TelegramService;

class NotifyOn
{
    public $command = '/notify_on';
    
    public function handle($msg)
    {
        $telegramService = new TelegramService();
        $telegramService->toggleDailyNotification($msg->chat_id, true);
    }
}