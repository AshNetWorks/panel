<?php

namespace App\Plugins\Telegram\Commands;

use App\Models\User;
use App\Plugins\Telegram\Telegram;

class Help extends Telegram
{
    public $command = '/help';
    public $description = '显示帮助信息';
    
    public function handle($message, $match = [])
    {
        if (!$message->is_private) return;
        
        $user = User::where('telegram_id', $message->chat_id)->first();
        
        if (!$user) {
            $helpText = "🤖 *机器人帮助*\n———————————————\n";
            $helpText .= "❌ 您尚未绑定账户\n\n";
            $helpText .= "请先访问用户中心绑定您的 Telegram 账户后，即可使用以下功能：\n\n";
            $helpText .= "📊 查看流量使用情况\n";
            $helpText .= "🚪 获取内部群组邀请链接\n";
            $helpText .= "🔔 每日流量通知提醒\n";
            $helpText .= "⏰ 自定义通知时间设置\n";
            $helpText .= "🔄 订阅拉取通知功能\n\n";
            $helpText .= "绑定完成后发送 /start 开始使用！";
            
            $this->telegramService->sendMessage($message->chat_id, $helpText, 'markdown');
            return;
        }
        
        $helpText = "🤖 *机器人命令帮助*\n———————————————\n";
        $helpText .= "📊 /traffic - 查看流量使用情况\n";
        $helpText .= "🚪 /join - 获取内部群组邀请链接\n";
        $helpText .= "🔔 /notify_on - 开启每日流量通知\n";
        $helpText .= "🔕 /notify_off - 关闭每日流量通知\n";
        $helpText .= "⏰ /notify_time HH:MM - 设置通知时间\n";
        $helpText .= "❓ /help - 显示此帮助信息\n\n";
        
        $helpText .= "🔄 /subscribe_notify_on - 开启订阅拉取通知\n";
        $helpText .= "🔕 /subscribe_notify_off - 关闭订阅拉取通知\n\n";
        
        // 当前设置状态
        $subscribeNotifyStatus = $user->telegram_subscribe_notify ? '🟢 已开启' : '🔴 已关闭';
        $notifyStatus = $user->telegram_daily_traffic_notify ? '🟢 已开启' : '🔴 已关闭';
        $notifyTime = $user->telegram_notify_time ?? '23:50';
        
        $helpText .= "*当前设置：*\n";
        $helpText .= "流量通知：`{$notifyStatus}`\n";
        $helpText .= "通知时间：`{$notifyTime}`\n";
        $helpText .= "订阅通知：`{$subscribeNotifyStatus}`\n\n";
        
        $helpText .= "💡 提示：\n";
        $helpText .= "• 每日流量通知会在设定时间自动发送\n";
        $helpText .= "• 群组邀请链接24小时内有效，仅可使用一次\n";
        $helpText .= "• 订阅通知会在每次拉取时发送设备信息";
        
        $this->telegramService->sendMessage($message->chat_id, $helpText, 'markdown');
    }
}