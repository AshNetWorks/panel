<?php

namespace App\Plugins\Telegram\Commands;

use App\Models\User;
use App\Plugins\Telegram\Telegram;
use Illuminate\Support\Facades\Cache;

class Join extends Telegram {
    public $command = '/join';
    public $description = '获取内部群组邀请链接';

    public function handle($message, $match = []) {
        if (!$message->is_private) return;
        
        $telegramService = $this->telegramService;
        
        // 检查用户是否已绑定
        $user = User::where('telegram_id', $message->chat_id)->first();
        if (!$user) {
            $telegramService->sendMessage($message->chat_id, '❌ 您尚未绑定账户，请先绑定后再使用此功能');
            return;
        }
        
        // 检查用户状态
        if ($user->banned) {
            $telegramService->sendMessage($message->chat_id, '❌ 您的账户已被封禁，无法获取群组邀请');
            return;
        }
        
        // 检查用户是否有效（未过期）
        if ($this->isUserExpired($user)) {
            $telegramService->sendMessage($message->chat_id, '❌ 您的账户已过期，请续费后再获取群组邀请');
            return;
        }
        
        // 检查用户是否已经在群组中
        $groupChatId = -1002288730458; // 🔥 设置你的群组ID
        if ($this->isUserInGroup($user->telegram_id, $groupChatId)) {
            $telegramService->sendMessage($message->chat_id, 
                "✅ 您已经在群组中了！\n\n" .
                "🎉 无需重复获取邀请链接\n" .
                "💡 您可以直接在群组中交流和获取服务\n\n" .
                "🔍 如果您没有找到群组，请检查：\n" .
                "• 群组是否被折叠或归档\n" .
                "• 是否在其他设备上登录"
            );
            return;
        }
        
        // 检查是否已经生成过邀请链接且未使用
        $cacheKey = "tg_invite_{$user->telegram_id}";
        $existingInvite = Cache::get($cacheKey);
        
        if ($existingInvite && is_array($existingInvite) && isset($existingInvite['invite_link'])) {
            // 检查缓存的邀请是否还有效
            if ($this->isInviteValid($existingInvite)) {
                $remainingTime = $this->getRemainingTime($existingInvite['expires_at']);
                
                $telegramService->sendMessage($message->chat_id, 
                    "🔗 您已有一个有效的邀请链接：\n\n" .
                    "{$existingInvite['invite_link']}\n\n" .
                    "⚠️ 此链接仅可使用一次，剩余有效期：{$remainingTime}\n" .
                    "💡 请使用现有链接，避免重复申请\n\n" .
                    "🚫 **注意**：重复申请不会生成新链接"
                );
                return;
            } else {
                // 清除过期的缓存
                Cache::forget($cacheKey);
            }
        }
        
        // 创建一次性邀请链接
        $inviteLink = $this->createInviteLink($user, $groupChatId);
        
        if ($inviteLink) {
            $telegramService->sendMessage($message->chat_id, 
                "🎉 群组邀请链接生成成功！\n\n" .
                "🔗 **邀请链接：**\n" .
                "{$inviteLink}\n\n" .
                "⚠️ **重要提醒：**\n" .
                "• 此链接仅限您个人使用\n" .
                "• 链接仅可使用一次\n" .
                "• 有效期为30分钟\n" .
                "• 请勿分享给他人\n" .
                "• 加入群组后链接自动失效\n\n" .
                "💡 点击链接即可加入内部群组", 
                'markdown'
            );
        } else {
            $telegramService->sendMessage($message->chat_id, '❌ 邀请链接生成失败，请稍后重试或联系管理员');
        }
    }

    /**
     * 检查用户是否已在群组中
     */
    private function isUserInGroup($telegramUserId, $groupChatId) {
        try {
            $member = $this->telegramService->getChatMember($groupChatId, $telegramUserId);
            
            if ($member && isset($member->status)) {
                $status = $member->status;
                
                // 用户在群组中的状态：member, administrator, creator
                // 不在群组或被踢出的状态：left, kicked, restricted
                $inGroupStatuses = ['member', 'administrator', 'creator'];
                
                $isInGroup = in_array($status, $inGroupStatuses);
                
                \Log::info("检查用户群组状态", [
                    'user_id' => $telegramUserId,
                    'group_id' => $groupChatId,
                    'status' => $status,
                    'is_in_group' => $isInGroup
                ]);
                
                return $isInGroup;
            }
            
        } catch (\Exception $e) {
            \Log::warning('检查用户群组状态失败', [
                'user_id' => $telegramUserId,
                'group_id' => $groupChatId,
                'error' => $e->getMessage()
            ]);
        }
        
        // 出错时假设用户不在群组中，允许生成邀请（安全策略）
        return false;
    }

    /**
     * 计算剩余时间（人性化显示）
     */
    private function getRemainingTime($expiresAt) {
        try {
            $expiresTimestamp = is_numeric($expiresAt) ? (int) $expiresAt : strtotime($expiresAt);
            
            if ($expiresTimestamp === false) {
                return '无法计算';
            }
            
            $remaining = $expiresTimestamp - time();
            
            if ($remaining <= 0) {
                return '已过期';
            }
            
            $minutes = floor($remaining / 60);
            $seconds = $remaining % 60;
            
            if ($minutes > 0) {
                return $minutes . '分钟' . ($seconds > 30 ? '30秒' : '');
            } else {
                return max(1, $seconds) . '秒'; // 至少显示1秒
            }
            
        } catch (\Exception $e) {
            \Log::error('计算剩余时间失败: ' . $e->getMessage());
            return '计算失败';
        }
    }

    /**
     * 安全检查邀请是否有效
     */
    private function isInviteValid($inviteData) {
        try {
            if (!isset($inviteData['expires_at'])) {
                return false;
            }
            
            $expiresAt = $inviteData['expires_at'];
            $currentTime = time();
            
            // 转换过期时间为时间戳
            if (is_string($expiresAt)) {
                $expiresTimestamp = strtotime($expiresAt);
                if ($expiresTimestamp === false) {
                    return false;
                }
            } elseif (is_numeric($expiresAt)) {
                $expiresTimestamp = (int) $expiresAt;
            } else {
                return false;
            }
            
            // 检查是否过期
            return $currentTime < $expiresTimestamp;
            
        } catch (\Exception $e) {
            \Log::error('检查邀请有效性失败: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * 安全检查用户是否过期
     */
    private function isUserExpired($user) {
        try {
            $expiredAt = $user->expired_at;
            
            if (is_null($expiredAt)) {
                return false;
            }
            
            $expiredTimestamp = 0;
            
            if (is_string($expiredAt)) {
                $expiredTimestamp = strtotime($expiredAt);
                if ($expiredTimestamp === false) {
                    \Log::warning('无法解析字符串格式的过期时间', [
                        'user_id' => $user->id,
                        'expired_at' => $expiredAt
                    ]);
                    return false;
                }
            } elseif (is_numeric($expiredAt)) {
                $expiredTimestamp = (int) $expiredAt;
            } elseif (method_exists($expiredAt, 'getTimestamp')) {
                $expiredTimestamp = $expiredAt->getTimestamp();
            } else {
                \Log::warning('无法解析用户过期时间', [
                    'user_id' => $user->id,
                    'expired_at' => $expiredAt,
                    'type' => gettype($expiredAt)
                ]);
                return false;
            }
            
            return time() > $expiredTimestamp;
            
        } catch (\Exception $e) {
            \Log::error('用户过期检查异常', [
                'user_id' => $user->id,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * 创建一次性邀请链接
     */
    private function createInviteLink($user, $groupChatId) {
        try {
            $expireTimestamp = time() + 1800; // 30分钟后
            
            $response = $this->telegramService->createChatInviteLink($groupChatId, [
                'name' => "用户邀请 - {$user->email}",
                'expire_date' => $expireTimestamp,
                'member_limit' => 1,
                'creates_join_request' => false
            ]);
            
            if ($response && isset($response->invite_link)) {
                // 缓存邀请信息 - 使用纯数字时间戳
                $cacheKey = "tg_invite_{$user->telegram_id}";
                $inviteData = [
                    'invite_link' => $response->invite_link,
                    'user_id' => $user->id,
                    'user_email' => $user->email,
                    'created_at' => time(),
                    'expires_at' => $expireTimestamp
                ];
                
                // 缓存30分钟
                Cache::put($cacheKey, $inviteData, 30);
                
                \Log::info("为用户 {$user->email} (ID: {$user->id}) 生成群组邀请链接", [
                    'invite_link' => $response->invite_link,
                    'expires_timestamp' => $expireTimestamp,
                    'expires_date' => date('Y-m-d H:i:s', $expireTimestamp),
                    'group_check_passed' => true
                ]);
                
                return $response->invite_link;
            } else {
                \Log::error('Telegram API 未返回邀请链接', [
                    'response' => $response,
                    'user_id' => $user->id
                ]);
            }
            
        } catch (\Exception $e) {
            \Log::error('创建邀请链接异常', [
                'error' => $e->getMessage(),
                'user_id' => $user->id,
                'group_id' => $groupChatId
            ]);
        }
        
        return false;
    }
}