<?php

namespace App\Plugins\Telegram\Commands;

use App\Plugins\Telegram\Telegram;
use App\Models\User;

class SubscribeNotifyOff extends Telegram
{
    public $command = '/subscribe_notify_off';
    public $description = '关闭订阅拉取通知';
    
    public function handle($message, $match = [])
    {
        if (!$message->is_private) return;
        
        $user = User::where('telegram_id', $message->chat_id)->first();
        if (!$user) {
            $this->telegramService->sendMessage($message->chat_id, '❌ 未找到绑定的用户信息');
            return;
        }
        
        $user->telegram_subscribe_notify = false;
        $user->save();
        
        $this->telegramService->sendMessage($message->chat_id, '❌ 订阅拉取通知已关闭');
    }
}