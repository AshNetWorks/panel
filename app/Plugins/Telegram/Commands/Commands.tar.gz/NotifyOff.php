<?php

namespace App\Plugins\Telegram\Commands;

use App\Services\TelegramService;

class NotifyOff
{
    public $command = '/notify_off';
    
    public function handle($msg)
    {
        $telegramService = new TelegramService();
        $telegramService->toggleDailyNotification($msg->chat_id, false);
    }
}