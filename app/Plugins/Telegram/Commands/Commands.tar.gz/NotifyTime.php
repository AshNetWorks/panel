<?php

namespace App\Plugins\Telegram\Commands;

use App\Services\TelegramService;

class NotifyTime
{
    public $command = '/notify_time';
    
    public function handle($msg)
    {
        $telegramService = new TelegramService();
        
        if (empty($msg->args)) {
            $telegramService->sendMessage($msg->chat_id, '❌ 请输入时间，格式：/notify_time 23:50');
            return;
        }
        
        $time = $msg->args[0];
        $telegramService->setNotificationTime($msg->chat_id, $time);
    }
}
