<?php

namespace App\Plugins\Telegram\Commands;

use App\Models\User;
use App\Plugins\Telegram\Telegram;
use Illuminate\Support\Facades\Cache;

class Welcome extends Telegram {
    
    /**
     * 处理新用户加入群组 - 安全简化版本
     */
    public function handleNewMember($message) {
        // 设置目标群组ID
        $targetGroupId = -1002288730458; // 🔥 设置你的群组ID
        
        if ($message->chat->id != $targetGroupId) {
            return; // 不是目标群组，忽略
        }
        
        // 处理新加入的用户
        if (isset($message->new_chat_members)) {
            foreach ($message->new_chat_members as $newMember) {
                $this->processNewMember($message->chat->id, $newMember);
            }
        }
    }
    
    /**
     * 处理单个新成员
     */
    private function processNewMember($chatId, $newMember) {
        $userName = $this->getUserDisplayName($newMember);
        
        try {
            // 检查用户是否已绑定TG账户
            $user = User::where('telegram_id', $newMember->id)->first();
            
            if (!$user) {
                // 用户未绑定，踢出群组
                $this->kickUnboundUser($chatId, $newMember, $userName);
                return;
            }
            
            // 检查用户状态（可选）
            if ($user->banned) {
                $this->kickBannedUser($chatId, $newMember, $userName);
                return;
            }
            
            // 用户已绑定且状态正常，发送欢迎消息
            $this->sendWelcomeMessage($chatId, $newMember, $user, $userName);
            
            // 清除用户的邀请缓存（已成功进群）
            $cacheKey = "tg_invite_{$user->telegram_id}";
            Cache::forget($cacheKey);
            
        } catch (\Exception $e) {
            \Log::error('处理新成员异常', [
                'error' => $e->getMessage(),
                'chat_id' => $chatId,
                'user_id' => $newMember->id
            ]);
        }
    }
    
    /**
     * 踢出未绑定用户
     */
    private function kickUnboundUser($chatId, $newMember, $userName) {
        try {
            // 尝试踢出用户
            if ($this->tryKickUser($chatId, $newMember->id)) {
                // 发送踢出通知
                $notificationText = "⚠️ 用户 {$userName} 因未绑定账户被移出群组\n\n";
                $notificationText .= "💡 **如需加入群组，请：**\n";
                $notificationText .= "1. 访问用户中心绑定 Telegram 账户\n";
                $notificationText .= "2. 绑定完成后私聊机器人发送 /join\n";
                $notificationText .= "3. 使用邀请链接重新加入群组\n\n";
                $notificationText .= "🤖 私聊机器人发送 /help 了解更多";
                
                $this->telegramService->sendMessage($chatId, $notificationText);
                
                \Log::info("踢出未绑定用户", [
                    'chat_id' => $chatId,
                    'user_id' => $newMember->id,
                    'username' => $newMember->username ?? null,
                    'reason' => 'not_bound'
                ]);
            }
            
        } catch (\Exception $e) {
            \Log::error("踢出未绑定用户失败", [
                'error' => $e->getMessage(),
                'chat_id' => $chatId,
                'user_id' => $newMember->id
            ]);
        }
    }
    
    /**
     * 踢出被封禁用户
     */
    private function kickBannedUser($chatId, $newMember, $userName) {
        try {
            if ($this->tryKickUser($chatId, $newMember->id)) {
                $notificationText = "⚠️ 用户 {$userName} 因账户被封禁而被移出群组\n\n";
                $notificationText .= "📞 如有疑问请联系管理员";
                
                $this->telegramService->sendMessage($chatId, $notificationText);
                
                \Log::info("踢出被封禁用户", [
                    'chat_id' => $chatId,
                    'user_id' => $newMember->id,
                    'reason' => 'user_banned'
                ]);
            }
            
        } catch (\Exception $e) {
            \Log::error("踢出被封禁用户失败", [
                'error' => $e->getMessage(),
                'chat_id' => $chatId,
                'user_id' => $newMember->id
            ]);
        }
    }
    
    /**
     * 尝试踢出用户（简化版本，避免API复杂性）
     */
    private function tryKickUser($chatId, $userId) {
        try {
            // 如果TelegramService有踢人方法，使用它
            if (method_exists($this->telegramService, 'banChatMember')) {
                $result = $this->telegramService->banChatMember($chatId, $userId);
                if ($result) {
                    // 立即解封，只是踢出不永久禁止
                    if (method_exists($this->telegramService, 'unbanChatMember')) {
                        $this->telegramService->unbanChatMember($chatId, $userId);
                    }
                    return true;
                }
            } else {
                \Log::warning('TelegramService缺少banChatMember方法');
            }
            
        } catch (\Exception $e) {
            \Log::error('踢出用户API调用失败: ' . $e->getMessage());
        }
        
        return false;
    }
    
    /**
     * 发送欢迎消息
     */
    private function sendWelcomeMessage($chatId, $newMember, $user, $userName) {
        $maskedEmail = $this->maskEmail($user->email);
        
        $welcomeText = "🎉 欢迎 {$userName} 加入我们的群组！\n\n";
        $welcomeText .= "✅ 已绑定账户：" . $this->escapeMarkdown($maskedEmail) . "\n";
        $welcomeText .= "📅 加入时间：" . date('Y-m-d H:i:s') . "\n\n";
        
        $welcomeText .= "📋 **群组须知：**\n";
        $welcomeText .= "• 请保持友善和专业的交流\n";
        $welcomeText .= "• 禁止发布广告和垃圾信息\n";
        $welcomeText .= "• 尊重其他成员的隐私\n";
        $welcomeText .= "• 有问题请联系管理员\n\n";
        
        $welcomeText .= "🤖 您可以私聊机器人使用以下功能：\n";
        $welcomeText .= "• /traffic - 查看流量使用情况\n";
        $welcomeText .= "• /help - 查看所有可用命令\n\n";
        
        $welcomeText .= "🎊 祝您使用愉快！";
        
        try {
            $this->telegramService->sendMessage($chatId, $welcomeText, 'markdown');
            
            \Log::info("发送欢迎消息", [
                'chat_id' => $chatId,
                'user_id' => $newMember->id,
                'username' => $newMember->username ?? null,
                'bound_email' => $user->email
            ]);
            
        } catch (\Exception $e) {
            \Log::error("发送欢迎消息失败", [
                'error' => $e->getMessage(),
                'chat_id' => $chatId,
                'user_id' => $newMember->id
            ]);
        }
    }
    
    /**
     * 邮箱打码处理 - 高安全方案
     */
    private function maskEmail($email) {
        if (empty($email) || strpos($email, '@') === false) {
            return '***@***.***';
        }
        
        $parts = explode('@', $email);
        $username = $parts[0];
        $domain = $parts[1];
        
        // 用户名：只显示第一个字符，其余用*替代（至少3个*）
        $maskedUsername = $username[0] . str_repeat('*', max(3, strlen($username) - 1));
        
        // 域名：只显示顶级域名，其余用*替代
        $domainParts = explode('.', $domain);
        $topDomain = end($domainParts); // 获取最后一部分（如.com, .org）
        $maskedDomain = '***.' . $topDomain;
        
        return $maskedUsername . '@' . $maskedDomain;
    }
    
    /**
     * 获取用户显示名称
     */
    private function getUserDisplayName($user) {
        if (!empty($user->username)) {
            return "@" . $user->username;
        } elseif (!empty($user->first_name)) {
            $name = $user->first_name;
            if (!empty($user->last_name)) {
                $name .= " " . $user->last_name;
            }
            return $name;
        } else {
            return "新用户";
        }
    }
    
    /**
     * 转义Markdown字符
     */
    private function escapeMarkdown($text) {
        $escapeChars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'];
        foreach ($escapeChars as $char) {
            $text = str_replace($char, '\\' . $char, $text);
        }
        return $text;
    }
}