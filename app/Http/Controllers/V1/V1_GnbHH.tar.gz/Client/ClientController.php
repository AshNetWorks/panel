<?php

namespace App\Http\Controllers\V1\Client;

use App\Http\Controllers\Controller;
use App\Protocols\General;
use App\Protocols\Singbox\Singbox;
use App\Protocols\Singbox\SingboxOld;
use App\Protocols\ClashMeta;
use App\Services\ServerService;
use App\Services\UserService;
use App\Utils\Helper;
use Illuminate\Http\Request;

// ✅ 新增引入
use Illuminate\Support\Facades\DB;
use Jenssegers\Agent\Agent;
use App\Services\TelegramService;
use App\Jobs\SendTelegramJob;
use Carbon\Carbon;

class ClientController extends Controller
{
    /**
     * ✅ IP白名单数组
     * 在此数组中的IP拉取订阅时不会发送通知
     */
    private $ipWhitelist = [
        '38.92.27.52'           // EmbyIP
    ];

    public function subscribe(Request $request)
    {
        $flag = $request->input('flag')
            ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $flag = strtolower($flag);
        $user = $request->user;

        $ip = $this->getRealIp($request);

        $userAgent = $request->header('User-Agent', 'unknown');
        $agent = new \Jenssegers\Agent\Agent();
        $agent->setUserAgent($userAgent);
        
        $os = $agent->platform();
        $userAgentLower = strtolower($userAgent);
        
        if ($agent->isAndroid()) {
            $os = 'Android';
        } elseif ($agent->isiOS()) {
            $os = 'iOS';
        } elseif ($agent->isMac()) {
            $os = 'macOS';
        } elseif ($agent->isWindows()) {
            $os = 'Windows';
        } elseif ($agent->isLinux()) {
            $os = 'Linux';
        } else {
            // 兜底：部分代理客户端判断
            if (strpos($userAgentLower, 'clash') !== false) {
                $os = 'Clash';
            } elseif (strpos($userAgentLower, 'singbox') !== false || strpos($userAgentLower, 'sing-box') !== false) {
                $os = 'Singbox';
            } elseif (strpos($userAgentLower, 'mihomo') !== false) {
                $os = 'Mihomo';
            } elseif (strpos($userAgentLower, 'quantumult') !== false) {
                $os = 'Quantumult';
            } elseif (strpos($userAgentLower, 'shadowrocket') !== false) {
                $os = 'Shadowrocket';
            } elseif (strpos($userAgentLower, 'surge') !== false) {
                $os = 'Surge';
            } else {
                $os = 'Unknown';
            }
        }
        
        $deviceType = $agent->isMobile() ? 'Mobile' :
            ($agent->isTablet() ? 'Tablet' :
            ($agent->isDesktop() ? 'Desktop' : 'Unknown'));

        // ===== 获取IP归属地 =====
        $location = $this->getIpLocation($ip);

        // ✅ 检查IP是否在白名单中，如果在白名单中则跳过日志记录和通知
        if ($this->isIpInWhitelist($ip)) {
            \Log::debug("IP在白名单中，跳过日志记录和通知", [
                'ip' => $ip,
                'user_id' => $user->id,
                'user_agent' => $userAgent
            ]);
            
            // 直接处理订阅逻辑，不记录日志
            $userService = new UserService();
            if ($userService->isAvailable($user)) {
                $serverService = new ServerService();
                $servers = $serverService->getAvailableServers($user);
                
                // 处理线路参数的逻辑保持不变...
                $line = $request->input('line');
                if ($line !== null) {
                    $servers = $this->applyLineRules($servers, $line);
                }

                if($flag) {
                    if (!strpos($flag, 'sing')) {
                        $this->setSubscribeInfoToServers($servers, $user);
                        foreach (array_reverse(glob(app_path('Protocols') . '/*.php')) as $file) {
                            $file = 'App\\Protocols\\' . basename($file, '.php');
                            $class = new $file($user, $servers);
                            if (strpos($flag, $class->flag) !== false) {
                                return $class->handle();
                            }
                        }
                    }
                    if (strpos($flag, 'sing') !== false) {
                        $version = null;
                        if (preg_match('/sing-box\s+([0-9.]+)/i', $flag, $matches)) {
                            $version = $matches[1];
                        }
                        if (!is_null($version) && $version >= '1.12.0') {
                            $class = new Singbox($user, $servers);
                        } else {
                            $class = new SingboxOld($user, $servers);
                        }
                        return $class->handle();
                    }
                }
                $class = new General($user, $servers);
                return $class->handle();
            }
            return; // 白名单IP处理完毕，直接返回
        }

        // ✅ 非白名单IP才记录订阅拉取日志
        $logId = DB::table('v2_subscribe_pull_log')->insertGetId([
            'user_id' => $user->id,
            'ip' => $ip,
            'user_agent' => $userAgent,
            'os' => $os,
            'device' => $deviceType,
            'country' => $location['country'],
            'city' => $location['city'],
            'created_at' => now(),
        ]);

        // ✅ 发送 Telegram 通知（非白名单IP）
        $this->sendSubscribePullNotification($user, [
            'ip' => $ip,
            'os' => $os,
            'device' => $deviceType,
            'location' => $location,
            'user_agent' => $userAgent,
            'log_id' => $logId
        ]);

        // account not expired and is not banned.
        $userService = new UserService();
        if ($userService->isAvailable($user)) {
            $serverService = new ServerService();
            $servers = $serverService->getAvailableServers($user);
            
            // 检查线路参数
            $line = $request->input('line');
            if ($line !== null) {
                $servers = $this->applyLineRules($servers, $line);
            }

            if($flag) {
                if (!strpos($flag, 'sing')) {
                    $this->setSubscribeInfoToServers($servers, $user);
                    foreach (array_reverse(glob(app_path('Protocols') . '/*.php')) as $file) {
                        $file = 'App\\Protocols\\' . basename($file, '.php');
                        $class = new $file($user, $servers);
                        if (strpos($flag, $class->flag) !== false) {
                            return $class->handle();
                        }
                    }
                }
                if (strpos($flag, 'sing') !== false) {
                    $version = null;
                    if (preg_match('/sing-box\s+([0-9.]+)/i', $flag, $matches)) {
                        $version = $matches[1];
                    }
                    if (!is_null($version) && $version >= '1.12.0') {
                        $class = new Singbox($user, $servers);
                    } else {
                        $class = new SingboxOld($user, $servers);
                    }
                    return $class->handle();
                }
            }
            $class = new General($user, $servers);
            return $class->handle();
        }
    }

    /**
     * ✅ 应用线路规则
     * 
     * @param array $servers 服务器数组
     * @param string $line 线路参数
     * @return array
     */
    private function applyLineRules($servers, $line)
    {
        // 移动线路
        if (strcasecmp($line, 'cm') === 0) {
            \Log::info('Applying CM line rules - line param found', [
                'line' => $line
            ]);
    
            return collect($servers)->map(function($server) {
                $tags = $server['tags'] ?? [];
                
                if (in_array('CM', $tags)) {
                    if (in_array('IEPL', $tags)) {
                        $server['host'] = "nasoi.ashsub.com";
                    } else {
                        $server['host'] = "goodlinecm.hy1i.cn";
                    }
                }
                return $server;
            })->toArray();
        }
        // 联通线路
        elseif (strcasecmp($line, 'cu') === 0) {
            \Log::info('Applying CU line rules - line param found', [
                'line' => $line
            ]);
    
            return collect($servers)->map(function($server) {
                $tags = $server['tags'] ?? [];
                
                if (in_array('CU', $tags)) {
                    if (in_array('IEPL', $tags)) {
                        $server['host'] = "nasoi.ashsub.com";
                    } else {
                        $server['host'] = "goodlinecu.hy1i.cn";
                    }
                }
                return $server;
            })->toArray();
        }
        // 电信线路
        elseif (strcasecmp($line, 'ct') === 0) {
            \Log::info('Applying CT line rules - line param found', [
                'line' => $line
            ]);
    
            return collect($servers)->map(function($server) {
                $tags = $server['tags'] ?? [];
                
                if (in_array('CT', $tags)) {
                    if (in_array('IEPL', $tags)) {
                        $server['host'] = "nasoi.ashsub.com";
                    } else {
                        $server['host'] = "goodlinect.hy1i.cn";
                    }
                }
                return $server;
            })->toArray();
        }

        return $servers;
    }

    /**
     * ✅ 发送订阅拉取通知
     * 
     * @param object $user 用户对象
     * @param array $pullInfo 拉取信息
     */
    private function sendSubscribePullNotification($user, $pullInfo)
    {
        // 检查是否启用 Telegram Bot
        if (!config('v2board.telegram_bot_enable', 0)) {
            return;
        }

        // 注意：白名单检查已经在上层处理，这里不需要再检查

        // 检查用户是否绑定了 Telegram 且开启了订阅拉取通知
        if (!$user->telegram_id || !$this->shouldSendPullNotification($user)) {
            return;
        }

        try {
            // 构建通知消息
            $message = $this->buildSubscribePullMessage($user, $pullInfo);
            
            // 使用队列异步发送通知
            SendTelegramJob::dispatch($user->telegram_id, $message);
            
            // ✅ 更新日志记录，标记通知已发送
            DB::table('v2_subscribe_pull_log')
                ->where('id', $pullInfo['log_id'])
                ->update(['notification_sent_at' => now()]);
            
            \Log::info("订阅拉取通知已加入队列", [
                'user_id' => $user->id,
                'user_email' => $user->email,
                'telegram_id' => $user->telegram_id,
                'ip' => $pullInfo['ip'],
                'os' => $pullInfo['os']
            ]);
            
        } catch (\Exception $e) {
            \Log::error("发送订阅拉取通知失败", [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
                'ip' => $pullInfo['ip']
            ]);
        }
    }

    /**
     * ✅ 检查IP是否在白名单中
     * 
     * @param string $ip IP地址
     * @return bool
     */
    private function isIpInWhitelist($ip)
    {
        try {
            // 使用当前类的白名单数组
            $whitelistIps = $this->ipWhitelist;
            
            if (empty($whitelistIps)) {
                return false;
            }

            // 检查完全匹配
            if (in_array($ip, $whitelistIps)) {
                return true;
            }

            // 检查CIDR匹配
            foreach ($whitelistIps as $whitelistIp) {
                if ($this->ipMatchesCidr($ip, $whitelistIp)) {
                    return true;
                }
            }

            return false;
            
        } catch (\Exception $e) {
            \Log::error("检查IP白名单时发生错误", [
                'ip' => $ip,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * ✅ 检查IP是否匹配CIDR格式
     * 
     * @param string $ip 要检查的IP
     * @param string $cidr CIDR格式的IP段
     * @return bool
     */
    private function ipMatchesCidr($ip, $cidr)
    {
        // 如果不包含/，说明不是CIDR格式，直接返回false
        if (strpos($cidr, '/') === false) {
            return false;
        }

        try {
            list($network, $mask) = explode('/', $cidr);
            
            // 验证IP格式
            if (!filter_var($ip, FILTER_VALIDATE_IP) || !filter_var($network, FILTER_VALIDATE_IP)) {
                return false;
            }
            
            $mask = (int)$mask;
            if ($mask < 0 || $mask > 32) {
                return false;
            }
            
            // 转换为长整型进行比较
            $ipLong = ip2long($ip);
            $networkLong = ip2long($network);
            $maskLong = -1 << (32 - $mask);
            
            return ($ipLong & $maskLong) === ($networkLong & $maskLong);
            
        } catch (\Exception $e) {
            \Log::error("CIDR匹配时发生错误", [
                'ip' => $ip,
                'cidr' => $cidr,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * ✅ 判断是否应该发送拉取通知
     * 
     * @param object $user 用户对象
     * @return bool
     */
    private function shouldSendPullNotification($user)
    {
        // 检查是否开启了订阅拉取通知（需要先添加数据库字段）
        if (isset($user->telegram_subscribe_notify) && !$user->telegram_subscribe_notify) {
            return false;
        }

        // ✅ 修改频率限制逻辑：检查5分钟内是否有记录（无论是否发送过通知）
        $recentLog = DB::table('v2_subscribe_pull_log')
            ->where('user_id', $user->id)
            ->where('created_at', '>=', Carbon::now()->subMinutes(5))
            ->orderBy('created_at', 'desc')
            ->first();

        if ($recentLog) {
            // 如果5分钟内有记录，检查是否已经发送过通知
            if (isset($recentLog->notification_sent_at) && $recentLog->notification_sent_at) {
                \Log::debug("订阅拉取通知被频率限制（已发送过通知）", [
                    'user_id' => $user->id,
                    'last_notification' => $recentLog->notification_sent_at
                ]);
                return false;
            }
            
            // 如果没有 notification_sent_at 字段或为空，则允许发送
            // 这样可以兼容没有该字段的情况
        }

        return true;
    }

    /**
     * ✅ 构建订阅拉取通知消息
     * 
     * @param object $user 用户对象
     * @param array $pullInfo 拉取信息
     * @return string
     */
    private function buildSubscribePullMessage($user, $pullInfo)
    {
        $message = "🔄 *订阅拉取通知*\n———————————————\n";
        $message .= "👤 用户：`" . $this->escapeMarkdown($user->email) . "`\n";
        $message .= "⏰ 时间：`" . Carbon::now()->format('Y-m-d H:i:s') . "`\n\n";
        
        // 设备信息
        $message .= "📱 设备信息：\n";
        $message .= "系统：`{$pullInfo['os']}`\n";
        $message .= "设备：`{$pullInfo['device']}`\n\n";
        
        // 网络信息
        $message .= "🌐 网络信息：\n";
        $message .= "IP地址：`{$pullInfo['ip']}`\n";
        $message .= "归属地：`{$pullInfo['location']['country']} {$pullInfo['location']['city']}`\n\n";
        
        // 安全提醒
        if ($this->isUnusualLocation($user, $pullInfo['location']) || 
            $this->isUnusualDevice($user, $pullInfo['os'])) {
            $message .= "⚠️ *安全提醒*\n";
            $message .= "检测到异常登录，如非本人操作请及时修改密码\n\n";
        }
        
        // 流量信息（简化版）
        $useTraffic = $user->u + $user->d;
        $totalTraffic = $user->transfer_enable;
        $remaining = Helper::trafficConvert($totalTraffic - $useTraffic);
        $usagePercent = $totalTraffic > 0 ? round(($useTraffic / $totalTraffic) * 100, 2) : 0;
        
        $message .= "📊 流量状态：\n";
        $message .= "剩余流量：`{$remaining}`\n";
        $message .= "使用率：`{$usagePercent}%`\n\n";
        
        $message .= "💡 如需关闭此通知，请发送 /subscribe_notify_off";
        
        return $message;
    }

    /**
     * ✅ 检查是否为异常地理位置
     * 
     * @param object $user 用户对象
     * @param array $currentLocation 当前位置
     * @return bool
     */
    private function isUnusualLocation($user, $currentLocation)
    {
        // 获取用户最近7天的登录位置
        $recentLocations = DB::table('v2_subscribe_pull_log')
            ->where('user_id', $user->id)
            ->where('created_at', '>=', Carbon::now()->subDays(7))
            ->select('country', 'city')
            ->distinct()
            ->get();

        // 如果是新位置且最近7天有其他位置记录，则认为异常
        if ($recentLocations->count() > 0) {
            $isKnownLocation = $recentLocations->contains(function ($location) use ($currentLocation) {
                return $location->country === $currentLocation['country'];
            });

            return !$isKnownLocation;
        }

        return false;
    }

    /**
     * ✅ 检查是否为异常设备
     * 
     * @param object $user 用户对象
     * @param string $currentOs 当前操作系统
     * @return bool
     */
    private function isUnusualDevice($user, $currentOs)
    {
        // 获取用户最近30天使用的操作系统
        $recentOs = DB::table('v2_subscribe_pull_log')
            ->where('user_id', $user->id)
            ->where('created_at', '>=', Carbon::now()->subDays(30))
            ->select('os')
            ->distinct()
            ->pluck('os')
            ->toArray();

        // 如果是新的操作系统，则认为可能异常
        return !empty($recentOs) && !in_array($currentOs, $recentOs);
    }

    /**
     * ✅ 转义 Markdown 字符
     * 
     * @param string $text 待转义文本
     * @return string
     */
    private function escapeMarkdown($text)
    {
        return str_replace(['*'], ['\\*'], $text); // 只转义星号，不转义下划线
    }

    private function setSubscribeInfoToServers(&$servers, $user)
    {
        if (!isset($servers[0])) return;
        if (!(int)config('v2board.show_info_to_server_enable', 0)) return;
        $useTraffic = $user['u'] + $user['d'];
        $totalTraffic = $user['transfer_enable'];
        $remainingTraffic = Helper::trafficConvert($totalTraffic - $useTraffic);
        $expiredDate = $user['expired_at'] ? date('Y-m-d', $user['expired_at']) : '长期有效';
        $userService = new UserService();
        $resetDay = $userService->getResetDay($user);
        array_unshift($servers, array_merge($servers[0], [
            'name' => "套餐到期：{$expiredDate}",
        ]));
        if ($resetDay) {
            array_unshift($servers, array_merge($servers[0], [
                'name' => "距离下次重置剩余：{$resetDay} 天",
            ]));
        }
        array_unshift($servers, array_merge($servers[0], [
            'name' => "剩余流量：{$remainingTraffic}",
        ]));
    }

    private function getRealIp(Request $request)
    {
        $headers = [
            'CF-Connecting-IP',
            'X-Real-IP',
            'X-Forwarded-For',
            'Forwarded',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_CLIENT_IP',
            'HTTP_X_REAL_IP'
        ];
        foreach ($headers as $header) {
            $ip = $request->header($header) ?: ($_SERVER[$header] ?? null);
            if ($ip) {
                // X-Forwarded-For 可能有多个逗号分隔的IP，取第一个
                $ip = explode(',', $ip)[0];
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        // 最后兜底
        return $request->ip();
    }

    private function getIpLocation($ip)
    {
        try {
            $response = @file_get_contents("http://ip-api.com/json/{$ip}?lang=zh-CN");
            $data = $response ? json_decode($response, true) : null;
            if ($data && $data['status'] === 'success') {
                return [
                    'country' => $data['country'] ?? '未知',
                    'city' => $data['city'] ?? '未知'
                ];
            }
        } catch (\Exception $e) {}
        return ['country' => '未知', 'city' => '未知'];
    }
}